package ThreadSystem;

import java.io.IOException;

import ThreadSystem.buffer;
import javax.swing.JOptionPane;
import javax.swing.text.LabelView;

import java.awt.event.*;  
import javax.swing.*;
class Producer extends Thread {
	
 buffer buf;
public int count =0;
public int bigPrime=0;
long startTime; 
 public Producer(buffer buf,long s ) {
 this.buf = buf;
 startTime=s;
 }
 
 public void run(){
	 
	JFrame f2=new JFrame("Output");
 for (int i = 2; i <= buf.getN(); i++) {
   if(isPrime(i)) {
	count++;
	bigPrime = i;
    buf.produce(i);}
  }
 System.out.println("Number of Prime Number = " + count);
 System.out.println("Big Prime Number = " + bigPrime);


  try {
	
	long endTime = System.currentTimeMillis();
	buf.closeFile();
	JLabel o1,o2,o3,o11,o22,o33;
	o1=new JLabel("largest number =");
	o1.setBounds(30,20, 300,30);
	o11=new JLabel(Integer.toString(bigPrime));
	o11.setBounds(310,20, 40,30);
	o2=new JLabel("# of prime numbers is = ");
	o2.setBounds(30,60, 300,30);
    o22=new JLabel(Integer.toString(count));  
    o22.setBounds(310,60, 40,30);
	o3=new JLabel("Time elapsed since the start of processing :  ");  
    long ti = (endTime - startTime);
    String tim =String.valueOf(ti)+ " ms" ;
    o3.setBounds(30,90, 300,30);
    o33=new JLabel(tim);  
    o33.setBounds(310,90, 200,30);
	f2.add(o1);f2.add(o11);f2.add(o2);f2.add(o22);
    f2.add(o3);f2.add(o33);
    f2.setSize(450,230); 
    f2.setLayout(null);  
    f2.setVisible(true);

  } catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
  }
            
 
 }
 
	public static boolean isPrime(int number) {
	
	boolean isPrime = true;
	for(int i = 2 ; i < number ; i++) {
		if(number%i == 0) {
			isPrime = false;
			break;
		}
	}
	
	return isPrime;
}
 
}