package ThreadSystem;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

class buffer {

  static Scanner reader = new Scanner(System.in);
  static FileWriter fout;

  private int size; // the buffer bound
  private int store[];
  private int inptr = 0;
  private int outptr = 0;
  private  int N;
  
  Semaphore spaces ;
  Semaphore elements = new Semaphore(0);
  
  public buffer(int size , int N){
	  this.N = N;
	  this.size = size;
	  store = new int[this.size];
	  spaces = new Semaphore(size);
  }
  
  public int getSize() {
	  return this.size;
  }
  
  public int getN() {
	  return this.N;
  }
  
  public void openFile(String File) throws IOException {
		 fout = new FileWriter(File);
  }
  
  public void closeFile() throws IOException {
	
	fout.close();
  }
  
  public void produce(int value) {
  spaces.P();
  store[inptr] = value;
  inptr = (inptr + 1) % size;
  elements.V();
  }
  
  public int consume() throws IOException {
	  
  elements.P();
  fout.write("\"" + store[outptr] + "\" ");
  outptr = (outptr + 1) % size;
  spaces.V();
  return store[outptr];
  }
  
}