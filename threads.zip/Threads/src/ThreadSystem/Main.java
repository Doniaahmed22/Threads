package ThreadSystem;

import java.io.IOException;
import java.util.Scanner;
import javax.swing.JOptionPane;
import java.awt.event.*;  
import javax.swing.*;
public class Main {

	public static void main(String[] args) throws InterruptedException, IOException {
		JFrame f=new JFrame("Calculate prime number");  
             JLabel l1,l2,l3;
             l1=new JLabel("Enter N : ");  
             l1.setBounds(30,30, 100,20); 
			final JTextField tf=new JTextField();
             tf.setBounds(170,25, 150,20);
			 l3=new JLabel("Enter buffer size : ");  
             l3.setBounds(30,50, 100,30);
			 final JTextField tf3=new JTextField();
			 tf3.setBounds(170,50, 150,20);
             l2=new JLabel("Enter File Name only(without .txt) : ");  
             l2.setBounds(30,70, 100,30); 
             final JTextField tf2=new JTextField();  
             tf2.setBounds(170,75, 150,20);
             JButton b=new JButton("Generate");  
             b.setBounds(30,110,150,20);  
			 b.addActionListener(new ActionListener(){
				long startTime = System.currentTimeMillis();   
				public void actionPerformed(ActionEvent e){  
				   long startTime = System.currentTimeMillis();                
				   int n = Integer.valueOf(tf.getText());
				   int buff_size=Integer.valueOf(tf3.getText());
				   final buffer buf = new buffer(buff_size,n);
				   String file= String.valueOf(tf2.getText());
				   try {
					buf.openFile(file);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
					Producer producerThread = new Producer(buf,startTime);
					Consumer consumerThread = new Consumer(buf);
			        producerThread.start();
					consumerThread.start();
				   
				   
				   }  
		});
		        f.add(tf);
				f.add(tf3);
                f.add(tf2);
                f.add(b);
                f.add(l1);f.add(l3); f.add(l2);  
                f.setSize(450,300);  
                f.setLayout(null);  
                f.setVisible(true); 

		  
	
	}

}