package ThreadSystem;

import java.io.IOException;
import java.util.Scanner;

class Consumer extends Thread {

 buffer buf;
 
 public Consumer(buffer buf) {
 this.buf = buf;
 }
 
 public void run() {
 while(true) {
	 try {
		buf.consume();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
 }
 
 }
 
}